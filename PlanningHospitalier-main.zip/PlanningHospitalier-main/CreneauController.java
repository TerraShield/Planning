

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import com.mysql.cj.jdbc.MysqlDataSource;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.layout.HBox;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import javafx.stage.Stage;

public class CreneauController {
	private static ObservableList<String> DeleteData =	FXCollections.observableArrayList(); //Ce sont les données qu'on met dans le tableau 
	  public static void NewCreneauFactory() {
			Stage newWindow = new Stage();
			TilePane tilePane = new TilePane();
			tilePane.setHgap(30);
			tilePane.setVgap(5);
			Connection cn = JDBC();
			HBox duréeBox = new HBox();
			duréeBox.setSpacing(10);
			Text heureDurée = new Text("0");
			Text minuteDurée = new Text("0");
			Label labelDurée = new Label(heureDurée.getText() + "h" + minuteDurée.getText());
			Text dateFinLabel = new Text();
			VBox personnelBox = new VBox(); 
			
			//Content for popup
			Popup popup = new Popup();
			Label IncorrectLabel = new Label("Incorrect");
			Label CorrectLabel = new Label();
			popup.getContent().add(IncorrectLabel);
			popup.getContent().add(CorrectLabel);
			IncorrectLabel.setVisible(false);
			CorrectLabel.setVisible(false);
			popup.setAnchorX(1200);
			popup.setAnchorY(600);
			popup.setHideOnEscape(true);
			
			//Permet de fermer la nouvelle fenêtre
			Button close = new Button("Fermer");
			close.setOnAction(new EventHandler<ActionEvent>() {
				public void handle(ActionEvent e ) {
					newWindow.close();
				}
			});
			
			//Configuration de la date 
			Label labeldate = new Label();
			DatePicker datePicker = new DatePicker();
			datePicker.setOnAction(new EventHandler<ActionEvent>() {
				public void handle(ActionEvent event ) {
						labeldate.setText(datePicker.getValue().toString());
				}
			});
			
			//Configuration des heures
			Label labelHeure = new Label("Heure :");
			Slider heurePicker = new Slider(0, 24, 12);
			heurePicker.setShowTickLabels(true);
			heurePicker.setShowTickMarks(true);
			heurePicker.setMajorTickUnit(2);
			heurePicker.setSnapToTicks(true);
			heurePicker.valueProperty().addListener(
		             new ChangeListener<Number>() {
		                 public void changed(ObservableValue <? extends Number > 
		                           observable, Number oldValue, Number newValue)
		                 {
		                     labelHeure.setText("Heure : " + newValue.intValue() + "h");
		                 }
		             });
			
			//Configuration des minutes
			Label labelMinute = new Label("Minute : ");
			Slider minutePicker = new Slider(0, 45, 0);
			minutePicker.setBlockIncrement(15);
			minutePicker.setMajorTickUnit(15);
			minutePicker.setMinorTickCount(0);
			minutePicker.setShowTickLabels(true);
			minutePicker.setSnapToTicks(true);
			minutePicker.valueProperty().addListener(
			         new ChangeListener<Number>() {
			             public void changed(ObservableValue <? extends Number > 
	                     		   observable, Number oldValue, Number newValue)
				         {
				              labelMinute.setText("Minute : " + newValue.intValue() + "m");
				         }
				     });
			
			//Configuration des minutes
			Label Durée = new Label("Durée :");
			TextField duréeMinutePicker = new TextField();
			TextField duréeHeurePicker = new TextField();
			
			duréeMinutePicker.setTextFormatter(new TextFormatter<String>(change -> change.getControlNewText().length() <= 2 ? change : null));
			duréeHeurePicker.setTextFormatter(new TextFormatter<String>(change -> change.getControlNewText().length() <= 2 ? change : null));
			duréeHeurePicker.textProperty().addListener(
		             new ChangeListener<String>() {
		            	public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
		            		 if (!newValue.matches("\\d*")) {
		            			duréeHeurePicker.setText(newValue.replaceAll("[^\\d]", "")); 
		            		}
		            		if (newValue.matches("\\d*")) {
		            			if(newValue.isEmpty()) {
		            				heureDurée.setText("0");
		            			}
		            			else 
		            				heureDurée.setText(newValue);
		            		}
		            		labelDurée.setText(heureDurée.getText() + "h" + minuteDurée.getText());
		            	 }
		             });
			
			duréeMinutePicker.textProperty().addListener(
		             new ChangeListener<String>() {
		            	 public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
		            		 if (!newValue.matches("\\d*")) {
		            			 duréeMinutePicker.setText(newValue.replaceAll("[^\\d]", ""));   
		            		 }
		            		 if (newValue.matches("\\d*")) {
		            			 if (newValue.isEmpty()) {
		            				 minuteDurée.setText("0");
		            			 }
		            			 else {
		            				 minuteDurée.setText(newValue);
		            			 }
			            			if (!minuteDurée.getText().isEmpty())
			            				if(Integer.parseInt(minuteDurée.getText())> 59) {
			            				minuteDurée.setText("59");
			            				}
			            		}
			            		
			            		labelDurée.setText(heureDurée.getText() + "h" + minuteDurée.getText());
		            	}
		             });
			
			duréeMinutePicker.setMaxHeight(10);
			duréeMinutePicker.setMaxWidth(30);
			duréeHeurePicker.setMaxHeight(10);
			duréeHeurePicker.setMaxWidth(30);
			duréeMinutePicker.getText().trim();
			
			
			//Configuration du personnel
			Label Personnel = new Label("Personnel");
			TextField Nom = new TextField();
			//TextField Fonction = new TextField();
			//TextField Specialite = new TextField();
			Nom.setPromptText("Nom Prenom Fonction");
			personnelBox.getChildren().addAll(Personnel, Nom); 
			//Configuration de la selection de personnel
			ListView listPersonnel = new ListView();
			listPersonnel.setMaxWidth(300);
			listPersonnel.setMaxHeight(100);	
			
			Nom.textProperty().addListener(
	 	             new ChangeListener<String>() {
		            	 public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
		            		Statement st = null;
							ResultSet rs = null;
		            		try {
								st = cn.createStatement();
								String sqlQuery = ("SELECT idPersonnel, personnel.nom, personnel.prenom, fonction.nom AS fonctionnom FROM personnel \r\n"
										+ "INNER JOIN fonction ON personnel.IdFonction = fonction.idFonction\r\n"
										+ "WHERE CONCAT(personnel.nom,personnel.prenom,fonction.nom) LIKE '%"+ newValue.replaceAll("[\\s]", "%") +"%'");
								rs = st.executeQuery(sqlQuery);
							
							}
							catch(SQLException e) {
								System.err.println("Erreur requête SQL");
								e.printStackTrace();
							}
		            		try {
		            			ObservableList<String> PersonnelList =	FXCollections.observableArrayList();
		            			listPersonnel.getItems().clear();
		            			while(rs.next()) {
		            				String personnelNom= rs.getString("nom");
		            				String personnelPrenom = rs.getString("prenom");
		            				String personnelFonction = rs.getString("fonctionnom");
		            				String personnelId = rs.getString("idPersonnel");
		            				PersonnelList.add(personnelNom + " " + personnelPrenom + "  |  " + personnelFonction  + "  |  Id: " + personnelId);
		            				listPersonnel.setItems(PersonnelList);
		            			}
		            		}
		            		catch(SQLException e) {
		            			System.err.println("Erreur de parcours de ResultSet");
		            			e.printStackTrace();
		            		}
		            	}
		             });
			
			
			Label h = new Label("h");
			Text AccHeureDurée = new Text(heureDurée.getText());
			Text AccMinuteDurée = new Text(minuteDurée.getText());
			
			Button accept = new Button("Accepter");
			accept.setOnAction(new EventHandler<ActionEvent>() {
				public void handle(ActionEvent event ) {
					if (datePicker.getValue() != null && (Integer.valueOf(heureDurée.getText()) + Integer.valueOf(minuteDurée.getText())) != 0 && listPersonnel.getSelectionModel().getSelectedItem() != null) {
						Date dateFinPicker = new Date(datePicker.getValue().getYear(),datePicker.getValue().getMonthValue(),datePicker.getValue().getDayOfMonth());
							do {
								int tempsHeureRestant = Integer.valueOf(heureDurée.getText()) + (int)heurePicker.getValue();
								if(tempsHeureRestant > 23) {
									for(int i = tempsHeureRestant; i>23; i = i - 24) {
										tempsHeureRestant-=24;
										AccHeureDurée.setText(String.valueOf(tempsHeureRestant));
										dateFinPicker.setDate(dateFinPicker.getDate()+1)
	;								}
								}
								else {
									AccHeureDurée.setText(String.valueOf(Integer.valueOf(heureDurée.getText()) + (int)heurePicker.getValue()));
								}
								int tempsMinuteRestant = Integer.valueOf(minuteDurée.getText()) + (int)minutePicker.getValue();
								if(tempsMinuteRestant > 59) {
									for(int i = tempsMinuteRestant; i>59; i = i - 60) {
										tempsMinuteRestant-=60;
										AccMinuteDurée.setText(String.valueOf(tempsMinuteRestant));
										AccHeureDurée.setText(String.valueOf(Integer.valueOf(AccHeureDurée.getText())+1));
									}
								}
								else {
									AccMinuteDurée.setText(String.valueOf(Integer.valueOf(minuteDurée.getText()) + (int)minutePicker.getValue()));
								}
							}
							while(Integer.valueOf(AccHeureDurée.getText()) > 23 && Integer.valueOf(AccMinuteDurée.getText()) > 59);
							dateFinLabel.setText(dateFinPicker.getYear()+"-"+dateFinPicker.getMonth()+"-"+dateFinPicker.getDate());
							CorrectLabel.setText("DateDébut : " + datePicker.getValue().toString() + "\nHeureDebut : "+(int)heurePicker.getValue() + ":" + (int)minutePicker.getValue() +":00" + 
												"\ndateFin : " + dateFinLabel.getText() + "\nHeureFin : " + AccHeureDurée.getText() +":"+ AccMinuteDurée.getText() +":00\nPour : " + 
												listPersonnel.getSelectionModel().getSelectedItem().toString());
							
							if (!popup.isShowing()) { 
								popup.show(newWindow); 
								if(IncorrectLabel.isVisible()) {
									IncorrectLabel.setVisible(false);
									CorrectLabel.setVisible(true);
								}
								else 
									CorrectLabel.setVisible(true);
							   }
							else {
								CorrectLabel.setVisible(false);
								popup.hide(); 
							}	
					}
						else {
							if (!popup.isShowing()) { 
								popup.show(newWindow); 
								if(CorrectLabel.isVisible()) {
									IncorrectLabel.setVisible(true);
									CorrectLabel.setVisible(false);
								}
								else 
									IncorrectLabel.setVisible(true);
								}
								else {
									IncorrectLabel.setVisible(false);
									popup.hide(); 
							}
					}
						
					
				}
			});
			
	          
			//Permet de valider la création d'un nouveau créneau
			Button confirm = new Button("Valider");
					confirm.setOnAction(new EventHandler<ActionEvent>() {
						public void handle(ActionEvent event ) {
							Statement st = null;
							ResultSet rs1 = null;
							try {
								st = cn.createStatement();
								String sqlQuery = "SELECT COUNT(*) AS doublon FROM creneau WHERE '" + datePicker.getValue() + " " + (int)heurePicker.getValue() + ":" + (int)minutePicker.getValue() + ":00" + "' BETWEEN dateDebut AND dateFin OR '"+ dateFinLabel.getText() + " " + AccHeureDurée.getText() + ":" + AccMinuteDurée.getText() + ":00" + "' BETWEEN dateDebut AND dateFin" ;
								rs1 = st.executeQuery(sqlQuery);
							}
							catch(SQLException e) {
								System.err.println("Erreur requête SQL");
								e.printStackTrace();
							}
							try {
								rs1.next();
								int valeur = rs1.getInt("doublon");
								if (valeur == 0) {
									System.out.println(valeur);
									try {
										st = cn.createStatement();
										String sql = "INSERT INTO creneau(dateDebut,dateFin,idPersonnel) VALUES ('" + datePicker.getValue() + " " + (int)heurePicker.getValue() + ":" + (int)minutePicker.getValue() + ":00" + "','" + dateFinLabel.getText() + " " + AccHeureDurée.getText() + ":" + AccMinuteDurée.getText() + ":00','" + getNbr(listPersonnel.getSelectionModel().getSelectedItem().toString()) +"')";
										if(CorrectLabel.isVisible()) {
										int rs2 = st.executeUpdate(sql);
										popup.hide();
										}
										else
											System.out.println("Pas accepté");
										}
									catch(SQLException e) {
										System.err.println("Erreur requête SQL");
										e.printStackTrace();
									}
								}
								else {
									CorrectLabel.setText("Ce creneau ne peut être effectué");
									throw new SQLException();
								}
							} catch (SQLException e) {
								if (!popup.isShowing()) { 
									popup.show(newWindow); 
									if(CorrectLabel.isVisible()) {
										IncorrectLabel.setVisible(true);
										CorrectLabel.setVisible(false);
									}
									else 
										IncorrectLabel.setVisible(true);
									}
									else {
										IncorrectLabel.setVisible(false);
										popup.hide(); 
								}	
								e.printStackTrace();	
							}
						}	
				});
			
			duréeBox.getChildren().addAll(Durée);
			duréeBox.getChildren().addAll(duréeHeurePicker);
			duréeBox.getChildren().addAll(h);
			duréeBox.getChildren().addAll(duréeMinutePicker);
			tilePane.getChildren().addAll(datePicker);
			tilePane.getChildren().addAll(heurePicker);
			tilePane.getChildren().addAll(minutePicker);
			tilePane.getChildren().addAll(duréeBox);
			tilePane.getChildren().addAll(labeldate);
			tilePane.getChildren().addAll(labelHeure);
			tilePane.getChildren().addAll(labelMinute);
			tilePane.getChildren().addAll(labelDurée);
			tilePane.getChildren().addAll(personnelBox);
			tilePane.getChildren().addAll(listPersonnel);
			tilePane.getChildren().addAll(accept);
			tilePane.getChildren().addAll(confirm);
			tilePane.getChildren().addAll(close);
			Scene secondScene = new Scene(tilePane, 1100, 800);
			// New window (Stage)
			newWindow.setTitle("Création d'un creneau");
			newWindow.setScene(secondScene);
			newWindow.show();
		}
	
	public static void deleteCreneau() {
		Stage newWindow = new Stage();
		TilePane tilePane = new TilePane();
		tilePane.setHgap(5);
		tilePane.setVgap(5);
		VBox boutonsbox = new VBox();
		boutonsbox.setSpacing(10);
		Connection cn = JDBC();
		ListView listCreneau = new ListView();
		listCreneau.setMaxWidth(300);
		Label creneauselected = new Label("n° sélectionné: ");
		DeleteData.clear();
		
		//Permet de fermer la nouvelle fenêtre
		Button close = new Button("Fermer");
		close.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e ) {
				newWindow.close();
			}
		});
		
		//Configuration de la date 
		DatePicker datePicker = new DatePicker();
		datePicker.setOnAction(new EventHandler<ActionEvent>() {
		     public void handle(ActionEvent event) {
		    	listCreneau.getItems().clear();
		    	Statement st = null;
		    	ResultSet rs = null;
		    	try {
		 			st = cn.createStatement();
		 			String sqlQuery = "SELECT TIME(dateDebut) AS dateDebut, TIME(dateFin) AS dateFin FROM creneau WHERE DATE(dateDebut) = '" + datePicker.getValue()+ "' ORDER BY dateDebut ASC";
		 			rs = st.executeQuery(sqlQuery);
		 			if (rs.equals(null)) {
		 			}
		 		}
		 		catch(SQLException e) {
		 			System.err.println("Erreur requête SQL");
		 			e.printStackTrace();
		 		}
		 		try {
		 			while(rs.next()) {
		 				String heureDebut = rs.getString("dateDebut");
		 				String heureFin = rs.getString("dateFin");
		 				DeleteData.add(heureDebut + " " + heureFin );
		 				}
		 			}
		 		catch(SQLException e) {
		 			System.err.println("Erreur de parcours de ResultSet");
		 			e.printStackTrace();
		 		}
		     } 
		 });
		
		//permet de prendre en paramètre la date qui est pointé dans la liste
		Button Selectionner = new Button("Sélection");
		Selectionner.setOnAction(new EventHandler<ActionEvent>() {
		     public void handle(ActionEvent event) {
		    	Statement st = null;
		    	ResultSet rs = null;
		    	 try {
		 			st = cn.createStatement();
		 			String sqlQuery = "SELECT idCreneau FROM `creneau` WHERE CONCAT(TIME(dateDebut),\" \",TIME(dateFin)) = '" + listCreneau.getSelectionModel().getSelectedItem().toString()+"'";
		 			rs = st.executeQuery(sqlQuery);
		 		}
		 		catch(SQLException e) {
		 			System.err.println("Erreur requête SQL");
		 			e.printStackTrace();
		 		}
		    	 try {
			 			while(rs.next()) {
			 				String idcreneau = rs.getString("idCreneau");
			 				creneauselected.setText("n° sélectionné: " + idcreneau);
			 				}
			 			}
			 		catch(SQLException e) {
			 			System.err.println("Erreur de parcours de ResultSet");
			 			e.printStackTrace();
			 		}
		     }
		});

		Button delet = new Button("Supprimer");
		delet.setOnAction(new EventHandler<ActionEvent>() {
		     public void handle(ActionEvent event) {
		    	Statement st = null;
		    	int rs = 0;
		    	 try {
		 			st = cn.createStatement();
		 			String sqlQuery = "DELETE FROM `creneau` WHERE idcreneau = '" + getNbr(creneauselected.getText()) + "'";
		 			if (getNbr(creneauselected.getText()) != null)
		 			rs = st.executeUpdate(sqlQuery);
		 			else 
		 				creneauselected.setText("Réessayez");
		 		}
		 		catch(SQLException e) {
		 			System.err.println("Erreur requête SQL");
		 			e.printStackTrace();
		 		}
		     }
		});
		
		listCreneau.setItems(DeleteData);
		tilePane.getChildren().addAll(datePicker);
		tilePane.getChildren().addAll(listCreneau);
		boutonsbox.getChildren().addAll(Selectionner);
		boutonsbox.getChildren().addAll(close);
		boutonsbox.getChildren().addAll(creneauselected);
		boutonsbox.getChildren().addAll(delet);
		tilePane.getChildren().addAll(boutonsbox);
		Scene secondScene = new Scene(tilePane, 800, 400);
		newWindow.setTitle("Supression d'un créneau");
		newWindow.setScene(secondScene);
		newWindow.show();
	}
	
	public static Connection JDBC() {
		String databaseName="planninghospitalier";
		String url="jdbc:mysql://localhost:3306/"+databaseName+"?serverTimezone=UTC";
		String login="root"; // dans l'idal un login de connexion pour l'application, et non root...
		String password=""; // mot de passe avec xampp
		//String password="usbw"; // mot de passe root avec USBWebServer
		Connection cn=null;
		MysqlDataSource mysqlDS = new MysqlDataSource();
		mysqlDS.setURL(url);
		mysqlDS.setUser(login);
		mysqlDS.setPassword(password);
		try {
			cn = mysqlDS.getConnection();
		} catch (SQLException e1) {
			System.err.println("Erreur de parcours de connexion");
			e1.printStackTrace();
		}
		return cn;
	}
	
	private static String getNbr(String str) 
    { 
        // Remplacer chaque nombre non numérique par un espace
        str = str.replaceAll("[^\\d]", " "); 
        // Supprimer les espaces de début et de fin 
        str = str.trim(); 
        // Remplacez les espaces consécutifs par un seul espace
        str = str.replaceAll(" +", " "); 
  
        return str; 
    } 
}
