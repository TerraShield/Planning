

import java.util.Date;

import com.mysql.cj.jdbc.MysqlDataSource;

import javafx.beans.property.LongProperty;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.layout.HBox;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import javafx.stage.Stage;

import java.sql.*;
public class Creneau {
    private SimpleStringProperty date;
    private SimpleStringProperty plageHoraire;
    private SimpleStringProperty besoinsMinPersonnel;
    private SimpleStringProperty soir;
    private SimpleStringProperty matin;
    private SimpleStringProperty midi;
    
    public Creneau(String matin, String midi, String soir) {
        this.matin = new SimpleStringProperty(matin);
        this.midi = new SimpleStringProperty(midi);
        this.soir = new SimpleStringProperty(soir);
    }
    
 
    public void setMatin(String value) { matinProperty().set(value); }
    
    public String getMatin() { return matinProperty().get(); }
    
    public StringProperty matinProperty() { 
        if (matin == null) matin = new SimpleStringProperty(this, "matin");
        return matin; 
    }


    
    public void setMidi(String value) { midiProperty().set(value); }
    
    public String getMidi() { return midiProperty().get(); }
    
    public StringProperty midiProperty() {
        if (midi == null) midi = new SimpleStringProperty(this, "midi");
        return midi; 
    }

    
    public void setSoir(String value) { soirProperty().set(value); }
    
    public String getSoir() { return soirProperty().get(); }
    
    public StringProperty soirProperty() {
        if (soir == null) soir = new SimpleStringProperty(this, "soir");
        return soir; 
    }
	/**
	 * Permet de faire une nouvelle fenêtre, qui va se connecter à la bdd, et qui saura inscrire un nouveau créneau 
	 * avec les paramètres que l'utilisateur inscrira)
	*/
  
    
    public static Connection JDBC() {
		String databaseName="planninghospitalier";
		String url="jdbc:mysql://localhost:3306/"+databaseName+"?serverTimezone=UTC";
		String login="root"; // dans l'idal un login de connexion pour l'application, et non root...
		String password=""; // mot de passe avec xampp
		//String password="usbw"; // mot de passe root avec USBWebServer
		Connection cn=null;
		MysqlDataSource mysqlDS = new MysqlDataSource();
		mysqlDS.setURL(url);
		mysqlDS.setUser(login);
		mysqlDS.setPassword(password);
		try {
			cn = mysqlDS.getConnection();
		} catch (SQLException e1) {
			System.err.println("Erreur de parcours de connexion");
			e1.printStackTrace();
		}
		return cn;
	}
}
