

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.jdbc.MysqlDataSource;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PersonnelController {
	private static ObservableList<String> FonctionData =	FXCollections.observableArrayList();
	private static ObservableList<String> FonctionPersonnelData =	FXCollections.observableArrayList();
	public static void fonctionController() {
		//Initialiser toutes les données qui vont être utilisé dans la méthode
		Stage newWindow = new Stage();
		Connection cn = JDBC();
		FonctionData.clear();
		FonctionPersonnelData.clear();
		
		//Initialiser le tilePane pour arranger les différents objets
		TilePane tilePane = new TilePane();
		tilePane.setHgap(5);
		tilePane.setVgap(5);
		
		//Initialiser la box pour stocker les boutons (Selectionner et close)
		VBox boutonsbox = new VBox();
		boutonsbox.setMaxWidth(100);
		boutonsbox.setSpacing(10);
		
		//Initialiser la box pour stocker la listFonction, et les boutons / champs de saisies qui vont avec
		VBox listFonctionBox = new VBox();
		TextField newFonction = new TextField();
		newFonction.setMaxWidth(200);
		newFonction.setPromptText("Fonction");
		Button buttonNewFonction = new Button("Accepter");
		Button buttonDeleteFonction = new Button("Supprimer");
		
		//Initialiser la box pour stocker la listFonctionPersonnel, et les boutons / champs de saisies qui vont avec
		VBox listFonctionPersonnelBox = new VBox();
		TextField newPersonnelNom = new TextField();
		TextField newPersonnelPrenom = new TextField();
		newPersonnelNom.setMaxWidth(100);
		newPersonnelPrenom.setMaxWidth(100);
		newPersonnelNom.setPromptText("Nom");
		newPersonnelPrenom.setPromptText("Prenom");
		Button buttonNewPersonnel = new Button("Accepter");
		Button buttonDeletePersonnel = new Button("Supprimer");
		
		//Initialiser les listes qui vont servir à stocker les données extraites de la base de données
		ListView listFonction = new ListView();
		ListView listFonctionPersonnel = new ListView();
		listFonction.setMaxWidth(300);
		listFonction.setMaxHeight(200);
		listFonctionPersonnel.setMaxWidth(300);
		listFonctionPersonnel.setMaxHeight(200);
		
		//Initialiser les variables utiles à la connexion JDBC
		Statement st = null;
    	ResultSet rs = null;
    	
    	//Remplissage de la liste des fonctions
    	try {
 			st = cn.createStatement();
 			String sqlQuery = "SELECT * FROM fonction";
 			rs = st.executeQuery(sqlQuery);
 			if (rs.equals(null)) {
 			}
 		}
 		catch(SQLException e) {
 			System.err.println("Erreur requête SQL");
 			e.printStackTrace();
 		}
 		try {
 			while(rs.next()) {
 				String idfonction = rs.getString("idFonction");
 				String nom = rs.getString("nom");
 				FonctionData.add(idfonction + " " + nom);
 				}
 			}
 		catch(SQLException e) {
 			System.err.println("Erreur de parcours de ResultSet");
 			e.printStackTrace();
 		}
 		
		//Permet de fermer la nouvelle fenêtre
		Button close = new Button("Fermer");
		close.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e ) {
				newWindow.close();
			}
		});
		
		Button Selectionner = new Button("Sélection");
		Selectionner.setOnAction(new EventHandler<ActionEvent>() {
		     public void handle(ActionEvent event) {
		    	listFonctionPersonnel.getItems().clear();
		    	Statement st = null;
		    	ResultSet rs = null;
		    	try {
		 			st = cn.createStatement();
		 			if (listFonction.getSelectionModel().getSelectedItem() != null) {
			 			String sqlQuery = "SELECT nom, prenom, idPersonnel FROM `personnel` WHERE idFonction = '"+ getNbr(listFonction.getSelectionModel().getSelectedItem().toString()) + "'";
			 			rs = st.executeQuery(sqlQuery);
		 			}
		 		}
		 		catch(SQLException e) {
		 			System.err.println("Erreur requête SQL");
		 			e.printStackTrace();
		 		}
		    	if (rs != null) {
					 try {
							while(rs.next()) {
								String nomPersonnel = rs.getString("nom");
								String prenomPersonnel = rs.getString("prenom");
								String idpersonnel = rs.getString("idPersonnel");
								FonctionPersonnelData.add(idpersonnel + " " + nomPersonnel + " " + prenomPersonnel);
							}
						}
					 catch(SQLException e) {
						 System.err.println("Erreur de parcours de ResultSet");
						 e.printStackTrace();
					}
				}
		     }
		});
		
		buttonNewFonction.setOnAction(new EventHandler<ActionEvent>() {
		     public void handle(ActionEvent event) {
		    	 Statement st1 = null;
		    	 Statement st = null;
		    	 int rs1 = 0;
		    	 ResultSet rs = null;
			    	 try {
			 			st1 = cn.createStatement();
			 			if (!newFonction.getText().isEmpty()) {
				 			String sqlQuery = "INSERT INTO fonction(nom) VALUES ('" + newFonction.getText().toString() + "')";
				 			rs1 = st1.executeUpdate(sqlQuery);
			 			}
			 			else {
			 				newFonction.setStyle("-fx-prompt-text-fill: red");
			 			}
			 		}
			 		catch(SQLException e) {
			 			System.err.println("Erreur requête SQL");
			 			e.printStackTrace();
			 		}
			    	if (rs1!=0) {
			    		listFonction.getItems().clear();
			    		try {
			     			st = cn.createStatement();
			     			String sqlQuery = "SELECT * FROM fonction";
			     			rs = st.executeQuery(sqlQuery);
			     			if (rs.equals(null)) {
			     			}
			     		}
			     		catch(SQLException e) {
			     			System.err.println("Erreur requête SQL");
			     			e.printStackTrace();
			     		}
			     		try {
			     			while(rs.next()) {
			     				String idfonction = rs.getString("idFonction");
			     				String nom = rs.getString("nom");
			     				FonctionData.add(idfonction + " " + nom);
			     				}
			     			newFonction.setStyle("-fx-prompt-text-fill: grey");
			     			buttonNewFonction.setText("Accepter");
			     			newFonction.setText(null);
			     			}
			     		catch(SQLException e) {
			     			System.err.println("Erreur de parcours de ResultSet");
			     			e.printStackTrace();
			     		}
			    	}
			    	else {
			    		buttonNewFonction.setText("Reessayez");
			    	}
		     }
		});
		
		buttonDeleteFonction.setOnAction(new EventHandler<ActionEvent>() {
		     public void handle(ActionEvent event) {
		    	 Statement st = null;
		    	 int rs1 = 0;
		    	 ResultSet rs = null;
			    	 try {
			 			st = cn.createStatement();
			 			if (listFonction.getSelectionModel().getSelectedItem() != null) {
				 			String sqlQuery = "DELETE FROM `fonction` WHERE idFonction = '" + getNbr(listFonction.getSelectionModel().getSelectedItem().toString()) + "'";
				 			rs1 = st.executeUpdate(sqlQuery);
				 			buttonDeleteFonction.setText("Supprimer");
			 			}
			 			else 
			 				buttonDeleteFonction.setText("Réessayez");
			 		}
			 		catch(SQLException e) {
			 			System.err.println("Erreur requête SQL");
			 			e.printStackTrace();
			 		}
			    		if (rs1!=0) {
				    		listFonction.getItems().clear();
				    		try {
				     			st = cn.createStatement();
				     			String sqlQuery = "SELECT * FROM fonction";
				     			rs = st.executeQuery(sqlQuery);
				     			if (rs.equals(null)) {
				     			}
				     		}
				     		catch(SQLException e) {
				     			System.err.println("Erreur requête SQL");
				     			e.printStackTrace();
				     		}
				     		try {
				     			while(rs.next()) {
				     				String idfonction = rs.getString("idFonction");
				     				String nom = rs.getString("nom");
				     				FonctionData.add(idfonction + " " + nom);
				     				}
				     			newFonction.setStyle("-fx-prompt-text-fill: grey");
				     			buttonNewFonction.setText("Accepter");
				     			newFonction.setText(null);
				     			}
				     		catch(SQLException e) {
				     			System.err.println("Erreur de parcours de ResultSet");
				     			e.printStackTrace();
				     		}
				    	}
		     }
		});
		
		buttonNewPersonnel.setOnAction(new EventHandler<ActionEvent>() {
		     public void handle(ActionEvent event) {
		    	 Statement st1 = null;
		    	 Statement st = null;
		    	 int rs1 = 0;
		    	 ResultSet rs = null;
			    	 try {
			 			st1 = cn.createStatement();
			 			if (!newPersonnelPrenom.getText().isEmpty() && !newPersonnelNom.getText().isEmpty()) {
			 				if (listFonction.getSelectionModel().getSelectedItem() != null) {
				 				String sqlQuery = "INSERT INTO personnel(prenom, nom, IdFonction) VALUES ('" + newPersonnelPrenom.getText().toString() + "','" + newPersonnelNom.getText().toString() + "','" + getNbr(listFonction.getSelectionModel().getSelectedItem().toString()) + "')";
				 				rs1 = st1.executeUpdate(sqlQuery);
			 				}
			 			}
			 			else {
			 				if(newPersonnelPrenom.getText().toString() == null) {
			 					newPersonnelPrenom.setStyle("-fx-prompt-text-fill: red");
			 				} else if (newPersonnelNom.getText() == null) {
			 					newPersonnelNom.setStyle("-fx-prompt-text-fill: red");
			 				}
			 				else {
			 					newPersonnelPrenom.setStyle("-fx-prompt-text-fill: red");
			 					newPersonnelNom.setStyle("-fx-prompt-text-fill: red");
			 				}
			 			}
			 			
			 		}
			 		catch(SQLException e) {
			 			System.err.println("Erreur requête SQL");
			 			e.printStackTrace();
			 		}
			    	if (rs1!=0) {
			    		listFonctionPersonnel.getItems().clear();
				    	 try {
				 			st = cn.createStatement();
				 			if (listFonction.getSelectionModel().getSelectedItem() != null) {
					 			String sqlQuery = "SELECT nom, prenom, idPersonnel FROM `personnel` WHERE idFonction = '"+ getNbr(listFonction.getSelectionModel().getSelectedItem().toString()) + "'";
					 			rs = st.executeQuery(sqlQuery);
				 			}
				 			newPersonnelPrenom.setText(null);
				 			newPersonnelNom.setText(null);
				 		}
				 		catch(SQLException e) {
				 			System.err.println("Erreur requête SQL");
				 			e.printStackTrace();
				 		}
				    	if (rs != null) {
							 try {
									while(rs.next()) {
										String nomPersonnel = rs.getString("nom");
										String prenomPersonnel = rs.getString("prenom");
										String idpersonnel = rs.getString("idPersonnel");
										FonctionPersonnelData.add(idpersonnel + " " + nomPersonnel + " " + prenomPersonnel);
										}
									buttonNewPersonnel.setText("Accepter");
									newPersonnelPrenom.setStyle("-fx-prompt-text-fill: grey");
									newPersonnelNom.setStyle("-fx-prompt-text-fill: grey");
									}
							 catch(SQLException e) {
								 System.err.println("Erreur de parcours de ResultSet");
								 e.printStackTrace();
							}
						}
			    	}
			    	else {
			    		buttonNewPersonnel.setText("Reessayez");
			    	}
		     }
		});
		
		buttonDeletePersonnel.setOnAction(new EventHandler<ActionEvent>() {
		     public void handle(ActionEvent event) {
		    	 Statement st = null;
		    	 int rs1 = 0;
		    	 ResultSet rs = null;
			    	 try {
			 			st = cn.createStatement();
			 			if (listFonction.getSelectionModel().getSelectedItem() != null) {
				 			String sqlQuery = "DELETE FROM `personnel` WHERE idPersonnel = '" + getNbr(listFonctionPersonnel.getSelectionModel().getSelectedItem().toString()) + "'";
				 			rs1 = st.executeUpdate(sqlQuery);
				 			buttonDeletePersonnel.setText("Supprimer");
			 			}
			 			else 
			 				buttonDeletePersonnel.setText("Réessayez");
			 		}
			 		catch(SQLException e) {
			 			System.err.println("Erreur requête SQL");
			 			e.printStackTrace();
			 		}
			    	 if (rs1!=0) {
				    		listFonctionPersonnel.getItems().clear();
					    	 try {
					 			st = cn.createStatement();
					 			if (listFonction.getSelectionModel().getSelectedItem() != null) {
						 			String sqlQuery = "SELECT nom, prenom, idPersonnel FROM `personnel` WHERE idFonction = '"+ getNbr(listFonction.getSelectionModel().getSelectedItem().toString()) + "'";
						 			rs = st.executeQuery(sqlQuery);
					 			}
					 		}
					 		catch(SQLException e) {
					 			System.err.println("Erreur requête SQL");
					 			e.printStackTrace();
					 		}
					    	if (rs != null) {
								 try {
										while(rs.next()) {
											String nomPersonnel = rs.getString("nom");
											String prenomPersonnel = rs.getString("prenom");
											String idpersonnel = rs.getString("idPersonnel");
											FonctionPersonnelData.add(idpersonnel + " " + nomPersonnel + " " + prenomPersonnel);
											}
										buttonNewPersonnel.setText("Accepter");
										}
								 catch(SQLException e) {
									 System.err.println("Erreur de parcours de ResultSet");
									 e.printStackTrace();
								}
							}
				    	}
		     }
		});
		
		listFonction.setItems(FonctionData);
		listFonctionPersonnel.setItems(FonctionPersonnelData);
		listFonctionBox.getChildren().addAll(listFonction);
		listFonctionBox.getChildren().addAll(newFonction);
		listFonctionBox.getChildren().addAll(buttonNewFonction);
		listFonctionBox.getChildren().addAll(buttonDeleteFonction);
		listFonctionPersonnelBox.getChildren().addAll(listFonctionPersonnel);
		listFonctionPersonnelBox.getChildren().addAll(newPersonnelNom);
		listFonctionPersonnelBox.getChildren().addAll(newPersonnelPrenom);
		listFonctionPersonnelBox.getChildren().addAll(buttonNewPersonnel);
		listFonctionPersonnelBox.getChildren().addAll(buttonDeletePersonnel);
		tilePane.getChildren().addAll(listFonctionBox);
		boutonsbox.getChildren().addAll(Selectionner);
		boutonsbox.getChildren().addAll(close);
		tilePane.getChildren().addAll(boutonsbox);
		tilePane.getChildren().addAll(listFonctionPersonnelBox);
		Scene secondScene = new Scene(tilePane, 800, 400);
		newWindow.setTitle("Liste personnel/fonction");
		newWindow.setScene(secondScene);
		newWindow.show();
	}
	public static Connection JDBC() {
		String databaseName="planninghospitalier";
		String url="jdbc:mysql://localhost:3306/"+databaseName+"?serverTimezone=UTC";
		String login="root"; // dans l'idal un login de connexion pour l'application, et non root...
		String password=""; // mot de passe avec xampp
		//String password="usbw"; // mot de passe root avec USBWebServer
		Connection cn=null;
		MysqlDataSource mysqlDS = new MysqlDataSource();
		mysqlDS.setURL(url);
		mysqlDS.setUser(login);
		mysqlDS.setPassword(password);
		try {
			cn = mysqlDS.getConnection();
		} catch (SQLException e1) {
			System.err.println("Erreur de parcours de connexion");
			e1.printStackTrace();
		}
		return cn;
	}
	
	private static String getNbr(String str) 
    { 
        // Remplacer chaque nombre non numérique par un espace
        str = str.replaceAll("[^\\d]", " "); 
        // Supprimer les espaces de début et de fin 
        str = str.trim(); 
        // Remplacez les espaces consécutifs par un seul espace
        str = str.replaceAll(" +", " "); 
  
        return str; 
    } 
}
