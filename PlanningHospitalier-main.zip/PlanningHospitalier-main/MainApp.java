

import java.awt.Desktop;
import java.io.*;
import java.util.*;
import java.sql.*;
import com.mysql.cj.jdbc.MysqlDataSource;

import java.text.*;
import java.time.*;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.application.*;
import javafx.collections.*;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.*;
import javafx.stage.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;

public class MainApp  <S,T> extends Application {

private final TableView<Creneau> Planning = new TableView<>(); //C'est le tableau (le planning qu'on affiche)
private ObservableList<Creneau> PlanningData =	FXCollections.observableArrayList(); //Ce sont les données qu'on met dans le tableau 
private Date date = new Date();

	public static void main(String[] args) {
		launch(args);
	}
	
	public Connection JDBC() {
		String databaseName="planninghospitalier";
		String url="jdbc:mysql://localhost:3306/"+databaseName+"?serverTimezone=UTC";
		String login="root"; // dans l'idal un login de connexion pour l'application, et non root...
		String password=""; // mot de passe avec xampp
		//String password="usbw"; // mot de passe root avec USBWebServer
		Connection cn=null;
		MysqlDataSource mysqlDS = new MysqlDataSource();
		mysqlDS.setURL(url);
		mysqlDS.setUser(login);
		mysqlDS.setPassword(password);
		try {
			cn = mysqlDS.getConnection();
		} catch (SQLException e1) {
			System.err.println("Erreur de parcours de connexion");
			e1.printStackTrace();
		}
		return cn;
	}
	
	public void start(Stage primaryStage) {
		Connection cn = JDBC();
		Statement st = null;
		ResultSet rs = null;
		DateFormat format = new SimpleDateFormat("YYYY-MM-dd");
		DateFormat formatjour = new SimpleDateFormat("EEEEEEE");
		
		MenuBar menuBar = new MenuBar();
		VBox ApplicationBox = new VBox(10);
		ApplicationBox.getChildren().add(menuBar);
		HBox PagePrincipale = new HBox(300);
		VBox PanneauDroit = new VBox();
		VBox PanneauGauche = new VBox(); 
		HBox AffBox = new HBox(20);
		VBox AffJS = new VBox();
		VBox BtnContrainte = new VBox();
		HBox SaDTrie = new HBox();
		VBox SaD = new VBox();
		ApplicationBox.getChildren().add(PagePrincipale);
		PagePrincipale.getChildren().add(PanneauGauche);
		PagePrincipale.getChildren().add(PanneauDroit);	
		PanneauGauche.getChildren().add(AffBox);
		PanneauGauche.getChildren().add(SaDTrie);
		AffBox.getChildren().add(AffJS);
		
		DatePicker datePicker = new DatePicker();
		SaD.getChildren().add(datePicker);
		
		//Affichage Jour/Semaine
		ToggleGroup grp1 = new ToggleGroup();
		RadioButton rdbtn1 = new RadioButton("Jour");
		RadioButton rdbtn2 = new RadioButton("Semaine");
		rdbtn1.setToggleGroup(grp1);
		rdbtn2.setToggleGroup(grp1);
		AffJS.getChildren().add(rdbtn1);
		AffJS.getChildren().add(rdbtn2);
		
		
		//Affichage detaillee des fonctions de l'app
			
			//Affichage avec contrainte
			Label TxtContrainte = new Label("Affichage \ndes Contrainte");
			AffBox.getChildren().add(TxtContrainte);
			
			RadioButton rdbtnCtnte1 = new RadioButton("Contrainte");
			RadioButton rdbtnCtnte2 = new RadioButton("Contrainte");
			BtnContrainte.getChildren().add(rdbtnCtnte1);
			BtnContrainte.getChildren().add(rdbtnCtnte2);
			
			
			//Saisie Detaille
			TextField SaD1 = new TextField();
			SaD.getChildren().add(SaD1);
			
		//planning 
			
			//bandeau jour

			TableColumn JourCol = new TableColumn(formatjour.format(date).toString());
			TableColumn MorningCol = new TableColumn("Matin");
	        MorningCol.setCellValueFactory(new PropertyValueFactory<>("matin"));
	 
	        TableColumn AfternoonCol = new TableColumn("Midi");
	        AfternoonCol.setCellValueFactory(new PropertyValueFactory<>("midi"));
	 
	        TableColumn NightCol = new TableColumn("Soir");
	        NightCol.setCellValueFactory(new PropertyValueFactory<>("soir"));
	        
	        TableFactory(MorningCol, AfternoonCol, NightCol,date);
			
			
		//Boutton "précédent" pour reculer d'un jour dans le planning
		Button jourprc = new Button("Précédent");
		jourprc.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent ev) {
				date.setDate(date.getDate()-1);
				TableFactory(MorningCol,AfternoonCol,NightCol,date);
				
			}
		});
		
		//Boutton "suivant" pour avancer d'un jour dans le planning
		Button joursuiv = new Button("Suivant");
		joursuiv.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent ev) {
				date.setDate(date.getDate()+1);
				TableFactory(MorningCol,AfternoonCol,NightCol,date);
			}
		});
		
		//Boutton "Aujorud'hui" pour aller à la date du jour dans le planning
	    Button dateAjrd = new Button("Aujourd'hui");
        dateAjrd.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent ev) {
				date = new Date();
				TableFactory(MorningCol,AfternoonCol,NightCol,date);
			}
		});	
        
        //Un menu avec plusieur option 
		Menu menu1 = new Menu("Option");
		Menu menu2 = new Menu("Personnel");
		Menu menu3 = new Menu("Aide");
		menuBar.getMenus().addAll(menu1);
		menuBar.getMenus().addAll(menu2);
		menuBar.getMenus().addAll(menu3);
		
			//Permet de rafraichir le tableau (créer un tableau avec les mêmes paramètres que celui déjà affiché, permettant de faire une nouvelle connexion à la BDD en cas de changement)
			MenuItem menuItem1 = new MenuItem("Rafraichir");
			menuItem1.setOnAction( new EventHandler<ActionEvent>() {
				public void handle(ActionEvent ev) {
					TableFactory(MorningCol,AfternoonCol,NightCol,date);
				}
			});
			menu1.getItems().add(menuItem1);
			
			//Permet de faire une nouvelle fenêtre (celle ci est utilisé pour instancier un nouveau creneau)
			MenuItem menuItem2 = new MenuItem("Nouveau créneau");
			menuItem2.setOnAction( new EventHandler<ActionEvent>() {
				public void handle(ActionEvent ev) {
					CreneauController.NewCreneauFactory();
				}
			});
			menu1.getItems().add(menuItem2);
			
			//Permet la suppression d'un créneau
			MenuItem menuItem3 = new MenuItem("Enlever créneau");
			menuItem3.setOnAction( new EventHandler<ActionEvent>() {
				public void handle(ActionEvent ev) {
					CreneauController.deleteCreneau();
				}
			});
			menu1.getItems().add(menuItem3);
			
			//Visualisation de toutes les fonctions/specialités et l'aggrementation de la liste
			MenuItem menuItem4 = new MenuItem("Personnel");
			menuItem4.setOnAction( new EventHandler<ActionEvent>() {
				public void handle(ActionEvent ev) {
					PersonnelController.fonctionController();
				}
			});
			menu2.getItems().add(menuItem4);
			
			
			MenuItem menuItem5 = new MenuItem("Documentation");
			menuItem5.setOnAction( new EventHandler<ActionEvent>() {
				public void handle(ActionEvent ev) {
					File file = new File("C:\\Users\\lohan\\Downloads\\Documentation_Projet.txt");
					Desktop desktop = Desktop.getDesktop();
					try {
						desktop.open(file);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			});
			menu3.getItems().add(menuItem5);
			
		datePicker.setOnAction(new EventHandler<ActionEvent>() {
		     public void handle(ActionEvent t) {
		         LocalDate ldate = datePicker.getValue();
		         System.out.println(ldate.toString());
		         try {
					date = new SimpleDateFormat("yyyy-mm-dd").parse(ldate.toString());
					TableFactory(MorningCol, AfternoonCol, NightCol, date);
				} catch (ParseException e) {
					e.printStackTrace();
				}
		     }
		 });
		
		
		Planning.setItems(PlanningData);
		PanneauDroit.getChildren().add(Planning);
		SaDTrie.getChildren().add(SaD);
		AffBox.getChildren().add(BtnContrainte);
		HBox btnjrsvtprc = new HBox();
		btnjrsvtprc.getChildren().add(jourprc);
		btnjrsvtprc.getChildren().add(joursuiv);
		btnjrsvtprc.getChildren().add(dateAjrd);
		PanneauDroit.getChildren().add(btnjrsvtprc);
		
		//Affichage de base en jour
		Scene scene1 = new Scene(ApplicationBox, 1820, 980);
		primaryStage.setScene(scene1);
		primaryStage.show();
		
		//Passage Affichage Semaine
		rdbtn2.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				
			}
		});
		
		//Passage Affichage Jour
		rdbtn1.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				
			}
		});
		
		
	}
	
	
	/**
	 * Permet de faire un nouveau tableau à partir d'un tableau déjà existant. Ce tableau sera rempli avec les données stockées dans la BDD
	 * @param MorningCol Colonne "matin", créneaux entre 06h et 12h
	 * @param AfternoonCol Colonne "Apres midi", créneaux entre 12h et 18h
	 * @param NightCol Colonne "Nuit", créneaux entre 18h et 06h
	 * @param date Permet de prendre une date, et d'afficher le planning correspondant à celle ci
	 */
	private void TableFactory(TableColumn MorningCol, TableColumn AfternoonCol, TableColumn NightCol, Date date) {
		Planning.getColumns().clear();
		Planning.getItems().clear();
		Statement st = null;
		ResultSet rs = null;
		DateFormat formatjour = new SimpleDateFormat("EEEEEEE");
		DateFormat format = new SimpleDateFormat("YYYY-MM-dd");
		Connection cn = JDBC();
		
		TableColumn JourCol = new TableColumn(formatjour.format(date).toString());
        
        MorningCol.setSortable(false);
        AfternoonCol.setSortable(false);
        NightCol.setSortable(false);
		
		try {
			st = cn.createStatement();
			String sqlQuery = "SELECT HOUR(dateDebut) AS heureDebut, TIME(dateDebut) AS dateDebut, TIME(dateFin) AS dateFin FROM creneau WHERE DATE(dateDebut) = '" +format.format(date).toString()+ "' ORDER BY dateDebut ASC";
			rs = st.executeQuery(sqlQuery);
		}
		catch(SQLException e) {
			System.err.println("Erreur requête SQL");
			e.printStackTrace();
		}
		
		try {
			while(rs.next()) {
				int heureDebut = rs.getInt("heureDebut");
				String dateFin = rs.getString("dateFin");
				String dateDebut = rs.getString("dateDebut");
				if(heureDebut > 00 && heureDebut < 12) {
					PlanningData.add(new Creneau(dateDebut + "","",""));
					PlanningData.add(new Creneau(dateFin + "","",""));
				} else if(heureDebut >= 12 && heureDebut < 18) {
					PlanningData.add(new Creneau("",dateDebut + "",""));
					PlanningData.add(new Creneau("",dateFin + "",""));
				} else {
					PlanningData.add(new Creneau("","",dateDebut + ""));
					PlanningData.add(new Creneau("","",dateFin+ ""));
				}
			}
		}
		catch(SQLException e) {
			System.err.println("Erreur de parcours de ResultSet");
			e.printStackTrace();
		}
		Planning.setItems(PlanningData);
		JourCol.getColumns().addAll(MorningCol, AfternoonCol, NightCol);
		Planning.getColumns().addAll(JourCol);
	}
    
    /**
     * idée pour le tableau : mettre une premiere colonne avec toutes les heures dispo, prendre la valeur de la date à placer dans le tableau
     * et la comparer avec les heures stocké. Selectionner (selectionmenu je crois) sur une ligne permettrait de commencer à remplir à partir de la date 
     * du planning affiché et l'heureDurée qui est stockée en première colonne de la ligne (prendre en variable le n° de la ligne selectionnée quand tu lances l'option)
     * Implique que l'affichage jour soit que deux colonnes. 
     * Pour le planning semaine, faire en sorte de prendre d'abord tous les jours de la semaine sélectionné et d'en afficher les donnée première heureDurée par première heureDurée
     * si il n'y a pas de retour sql, ne rien afficher il en va de soit
     * Pour afficher les information en semaine, afficher une popup avec un fond blanc qui recouvrira une partie de la fenêtre et qui disparaitra à n'importe quel input
     * Pour la modification en double clique, faire de setonaction l'un dans l'autre
     */
}


