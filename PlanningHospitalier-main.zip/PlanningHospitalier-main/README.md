---------- Mode D'emploi ------------------------------------------------------------------------------------------------------------
|
|	Dans le code java : 
|	
|	Ajuster la taille de la nouvelle fenêtre pour qu'elle corresponde à la taille d'affichage de votre écran. 
|	(ligne 278 dans MainApp) (Defaut : 1820,980 pour un écran en format 1980 x 1020 en 100%)
|	Changer le raccourcie vers le README (donc l'avoir installé au préalable), pour pouvoir y accéder via l'application.
|	(ligne 206, avec le chemin absolu vers le fichier.txt)
|
|	Dans la base de donnée : 
|
|	Bien importer les données avec le nom de base de donnée : "planninghospitalier". Seuls des fonctions hospitalières et des spécialités 
|	seront importées. Les autres tables pourront être remplie via l'application (pareillement pour "fonctions", mais il s'agit là d'une base
|	solide sur laquelle démarrer correctement)
|	
|
|	
|------------------------------------------------------------------------------------------------------------------------------------
|
|	Dans l'application :
|
|	Une fois bien arrivé sur l'application, vous devez avoir un menu en haut, des boutons à gauche, ainsi que un objet 
|	de type calendrier et un champs pour écrire. Les boutons et le champs n'ont pas encore d'utilités. 
|	L'utilisation du calendrier instanciera le planning situé à droite à la date choisie.
|	Comme dit précédemment, le planning est situé à droite. Il affiche les créneaux qui sont stockés dans la base de donnée.
|	Ils seront donc affiché par rapport au jour et trié par l'heure à laquelle elles sont inscrites.
|	Les boutons suivants et précédents permettent de passer respectivement au jour suivant et au jour précédemment, ainsi qui le bouton 
|	aujourd'hui permettant de revenir à la date du jour.
|	Dans les options en haut:
|	On retrouve en premier lieux rafraîchir, qui permet simplement de rafraîchir le planning actuel, si il
|	y a eu des données rajoutées qui ne se seraient pas affichées correctement (ça ne devrait pas arriver mais au cas où, pas obligé de 
|	redémarrer).
|	On retrouve ensuite nouveau créneau. Ceci permet de créer un nouveau créneau avec un jeu d'horaires et un (et qu'un) personnel attribué dessus.
|	Pour pouvoir valider les données, il faut avoir une date sélectionner à l'aide du calendrier, une heure de début sélectionner grâce au slider, de même pour
|	les minutes de début. Puis une durée. Et enfin, un personnel sélectionné (vérifiez qu'il soit bien sélectionner dans le tableau à proximité). Pour trouver un personnel, 
|	il faut renseigner son nom, son prenom ou son fonction (mettre les trois fonctionne mais il faut que ça soit dans l'ordre suivant : nom - prenom - fonction).
|	Une fois que tout ceci est fait, on peut appuyer sur accepter pour vérifier la validité des données, puis si ça affiche un résumé des paramètres rentrées, 
|	appuyez sur valider. Si il y a une erreur, un texte apparaîtra, sinon, le texte apparu précédemment disparaitra.
|	On retrouve ensuite enlever créneau. Ceci permet de supprimer un créneau par rapport à une date souhaité. Une calendrier pour prendre une date se situe à gauche.
|	Cela affichera tous les créneaux associés à cette date. En sélectionner un dans le tableau et appuyez sur sélectionner affichera son numéro dans la base de donnée.
|	Appuyez sur supprimer pour accepter la suppression du créneau sélectionné. 
|	A coté des options, on retrouve personnel. Ceci permet la modération des fonctions et du personnels, ainsi que le visionnage de ces données.
|	A gauche ce trouvera un tableau représentant toutes les fonctions. Vous pourrez en rajouter une en saisissant son libellé juste en dessous du tableau dans la zone de texte
|	prévu à cette effet. Cliquer sur accepter pour valider votre modification et la rajouter à la liste. Une fonction peut être supprimée. Il faut donc cliquer sur une fonction dans
| 	le tableau, et utiliser le bouton supprimer qui se situe sous le tableau de fonctions. 
|	Une fois une fonction cliquée, il faut sélectionner (le bouton du milieu), pour afficher la liste des personnels correspondant à cette fonction. Pour rajouter du personnel,la même |	démarche que précédement est 
| préconisée. Seulement, il faut qu'une fonction soit déjà sélectionnée pour attribuer celle ci au personnel ajouté.
|	Enfin, une dernière option aide qui permet de vous mener juste ici. Pas besoin d'expliquer à quoi sert celle ci si vous êtes ici.
|
|------------------------------------------------------------------------------------------------------------------------------------


